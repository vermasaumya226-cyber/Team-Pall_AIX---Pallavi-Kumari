/* ==========================================================================
   PERSONAL STUDY PLANNER AGENT - INTERACTIVE SCRIPT ENGINE (V3 ADVANCED)
   Team: Pall_AIX | Track: AI Agent Track
   ========================================================================== */

// Global State
const appState = {
  subjects: [
    { id: 'subj-1', name: 'Calculus III', priority: 'Critical', attendance: 88 },
    { id: 'subj-2', name: 'Data Structures', priority: 'High', attendance: 92 },
    { id: 'subj-3', name: 'Physics Lab', priority: 'Normal', attendance: 78 }
  ],
  files: [
    {
      name: 'Syllabus_Calculus_2026.pdf',
      size: '1.4 MB',
      parsed: '14 Topics Extracted',
      url: null,
      content: `Calculus III Syllabus Summary & Deadlines:\n\n1. Multivariable Calculus & Partial Derivatives (Exam: Aug 12)\n2. Multiple Integrals in Cylindrical & Spherical Coordinates\n3. Vector Calculus: Green's Theorem & Stokes' Theorem\n\nAssignment 1 Due: Friday 11:59 PM`
    },
    {
      name: 'Timetable_Sem4.png',
      size: '820 KB',
      parsed: 'OCR Timetable Parsed',
      url: null,
      content: `OCR Extracted College Schedule:\n\n- Mon-Fri 09:00 AM - 01:00 PM: Core College Lectures\n- Tue/Thu 02:00 PM - 03:30 PM: Data Structures Lab\n\nDetected Free Self-Study Slots:\n- Morning: 07:00 AM - 09:00 AM\n- Afternoon: 03:30 PM - 06:00 PM\n- Evening: 07:00 PM - 10:00 PM`
    }
  ],
  freeSlots: [
    'Morning (7:00 AM - 9:00 AM)',
    'Afternoon (2:00 PM - 5:00 PM)',
    'Evening (6:30 PM - 10:00 PM)'
  ],
  scheduleBlocks: [
    { id: 'block-1', subject: 'Calculus III', topic: 'Multivariable Integration & Vectors', startTime: '14:00', endTime: '15:30', priority: 'Critical', done: false },
    { id: 'block-2', subject: 'Data Structures', topic: 'Binary Heap & Graph Algorithms', startTime: '16:00', endTime: '17:30', priority: 'High', done: false },
    { id: 'block-3', subject: 'Physics Lab', topic: 'Optics & Laser Interference Report', startTime: '18:30', endTime: '19:15', priority: 'Normal', done: false }
  ]
};

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide Icons
  if (window.lucide) lucide.createIcons();

  // Init Background & Effects
  initAuroraCanvas();
  initMouseGlow();
  initNavbar();
  initCounters();
  initFocusTimer();

  // Initial Studio Renders
  renderSubjects();
  renderFiles();
  renderScheduleBlocks();
  setupDragAndDrop();
  setupScheduleScannerDrop();
});

/* ==========================================================================
   WEB AUDIO SYNTHESIZER
   ========================================================================== */
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function playSound(type) {
  try {
    if (!audioCtx) audioCtx = new AudioContext();
    if (audioCtx.state === 'suspended') audioCtx.resume();

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    const now = audioCtx.currentTime;

    if (type === 'click') {
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.04);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
      osc.start(now);
      osc.stop(now + 0.04);
    } else if (type === 'success') {
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.08);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.start(now);
      osc.stop(now + 0.18);
    } else if (type === 'replan') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.linearRampToValueAtTime(700, now + 0.12);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    }
  } catch (e) {}
}

/* ==========================================================================
   NAVBAR & SCROLL UTILITIES
   ========================================================================== */
function scrollToSection(id) {
  playSound('click');
  const section = document.getElementById(id);
  if (section) section.scrollIntoView({ behavior: 'smooth' });
}

function initNavbar() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;
  window.addEventListener('scroll', () => {
    if (window.scrollY > 30) navbar.classList.add('scrolled');
    else navbar.classList.remove('scrolled');
  });
}

/* ==========================================================================
   PDF & DOCUMENT INTERACTIVE READER MODAL
   ========================================================================== */
function openPdfViewer(fileIdx) {
  playSound('click');
  const file = appState.files[fileIdx];
  if (!file) return;

  const modal = document.getElementById('pdf-modal');
  const titleEl = document.getElementById('pdf-modal-title');
  const downloadBtn = document.getElementById('pdf-download-btn');
  const container = document.getElementById('pdf-viewer-container');

  if (!modal || !container) return;

  titleEl.innerHTML = `<i data-lucide="file-text" style="color: #38BDF8;"></i> Preview: ${file.name}`;
  
  if (file.url) {
    downloadBtn.href = file.url;
    downloadBtn.style.display = 'inline-flex';
    // Embed interactive PDF object / iframe
    container.innerHTML = `
      <iframe src="${file.url}" style="width: 100%; height: 440px; border: none; border-radius: 10px; background: white;"></iframe>
    `;
  } else {
    downloadBtn.style.display = 'none';
    // Display structured AI parsed text document view
    container.innerHTML = `
      <div style="font-family: monospace; white-space: pre-wrap; font-size: 0.9rem; color: #CBD5E1; line-height: 1.6;">
        <div style="background: rgba(124, 58, 237, 0.15); border: 1px solid rgba(124, 58, 237, 0.4); padding: 0.75rem 1rem; border-radius: 10px; margin-bottom: 1rem; font-family: var(--font-body); color: #E9D5FF;">
          <strong>📄 File:</strong> ${file.name} (${file.size}) • <span style="color: #34D399;">${file.parsed}</span>
        </div>
        ${file.content || 'Extracted Academic Constraints:\n- 14 Core Topics Identified\n- Exam Date: 2026-08-15\n- Minimum Target Threshold: 85%'}
      </div>
    `;
  }

  if (window.lucide) lucide.createIcons();
  modal.classList.add('active');
}

function closePdfModal() {
  playSound('click');
  const modal = document.getElementById('pdf-modal');
  if (modal) modal.classList.remove('active');
}

/* ==========================================================================
   CLASS SCHEDULE IMAGE OCR SCANNER & FREE TIME AUTO-DETECTION
   ========================================================================== */
function triggerScheduleImageInput() {
  playSound('click');
  const input = document.getElementById('schedule-img-input');
  if (input) input.click();
}

function setupScheduleScannerDrop() {
  const zone = document.getElementById('schedule-scanner-zone');
  if (!zone) return;

  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(evt => {
    zone.addEventListener(evt, (e) => {
      e.preventDefault();
      e.stopPropagation();
    }, false);
  });

  zone.addEventListener('drop', (e) => {
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processScheduleImage(files[0]);
    }
  });
}

function handleScheduleImageUploaded(e) {
  if (e.target.files && e.target.files.length > 0) {
    processScheduleImage(e.target.files[0]);
  }
}

function processScheduleImage(file) {
  playSound('replan');
  const laser = document.getElementById('laser-line');
  const resultContainer = document.getElementById('ocr-result-container');

  if (laser) laser.style.display = 'block';
  showToast('🔍 AI Laser scanning class schedule image for lecture slots...');

  setTimeout(() => {
    if (laser) laser.style.display = 'none';
    playSound('success');

    const imageUrl = URL.createObjectURL(file);
    appState.files.push({
      name: file.name,
      size: (file.size / 1024).toFixed(0) + ' KB',
      parsed: 'Class Schedule Image Scanned (3 Free Slots Found)',
      url: imageUrl,
      content: `OCR Timetable Scan Results:\n- College Classes: Mon-Fri 09:00 AM - 01:00 PM\n- Free Self-Study Windows Detected:\n  • Morning: 07:00 AM - 09:00 AM\n  • Afternoon: 02:00 PM - 05:00 PM\n  • Evening: 06:30 PM - 10:00 PM`
    });

    renderFiles();

    if (resultContainer) {
      resultContainer.style.display = 'block';
      resultContainer.innerHTML = `
        <div class="ocr-result-badge">
          <strong>📸 Timetable Image Scanned!</strong><br>
          Extracted College Lectures: 09:00 AM - 01:00 PM.<br>
          <span style="color: #FBBF24;">✨ Auto-detected 3 Free Study Windows & updated schedule!</span>
        </div>
      `;
    }

    // Auto-select free slot pills
    document.querySelectorAll('.slot-pill').forEach(pill => pill.classList.add('selected'));
    
    // Auto re-generate custom schedule matching new free slots
    generateCustomAISchedule();
    showToast('🎉 Free time slots auto-detected & study plan re-balanced!');
  }, 1400);
}

/* ==========================================================================
   SUBJECTS & FILES MANAGEMENT
   ========================================================================== */
function renderSubjects() {
  const container = document.getElementById('subjects-container');
  if (!container) return;

  container.innerHTML = '';
  appState.subjects.forEach(subj => {
    const badge = document.createElement('div');
    badge.className = 'subject-badge';
    const color = subj.priority === 'Critical' ? '#EF4444' : subj.priority === 'High' ? '#FBBF24' : '#34D399';
    badge.innerHTML = `
      <span style="width: 8px; height: 8px; border-radius: 50%; background: ${color};"></span>
      <strong>${subj.name}</strong> (${subj.attendance}%)
      <span class="remove-btn" onclick="removeSubject('${subj.id}')">&times;</span>
    `;
    container.appendChild(badge);
  });
  updateMetrics();
}

function addSubjectFromInputs() {
  playSound('click');
  const nameInput = document.getElementById('subj-name-input');
  const prioInput = document.getElementById('subj-priority-input');
  const attendInput = document.getElementById('subj-attend-input');

  if (!nameInput || !nameInput.value.trim()) {
    showToast('⚠️ Please enter a subject name.');
    return;
  }

  const newSubj = {
    id: 'subj-' + Date.now(),
    name: nameInput.value.trim(),
    priority: prioInput.value,
    attendance: parseInt(attendInput.value) || 85
  };

  appState.subjects.push(newSubj);
  nameInput.value = '';
  renderSubjects();
  showToast(`✅ Subject "${newSubj.name}" added to AI Engine.`);
}

function removeSubject(id) {
  playSound('click');
  appState.subjects = appState.subjects.filter(s => s.id !== id);
  renderSubjects();
}

function triggerFileInput() {
  playSound('click');
  const fileInput = document.getElementById('file-input');
  if (fileInput) fileInput.click();
}

function setupDragAndDrop() {
  const zone = document.getElementById('drop-zone');
  if (!zone) return;

  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    zone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
    }, false);
  });

  zone.addEventListener('dragover', () => zone.classList.add('dragover'));
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', (e) => {
    zone.classList.remove('dragover');
    processUploadedFiles(e.dataTransfer.files);
  });
}

function handleFilesSelected(e) {
  processUploadedFiles(e.target.files);
}

function processUploadedFiles(files) {
  if (!files || files.length === 0) return;
  playSound('replan');

  Array.from(files).forEach(file => {
    const fileUrl = URL.createObjectURL(file);
    const sizeStr = (file.size / 1024).toFixed(0) + ' KB';
    const parsedStr = file.name.endsWith('.pdf') ? '14 Syllabus Topics Extracted' :
                      file.name.match(/\.(png|jpg|jpeg)$/i) ? 'OCR Timetable Image Parsed' : 'Text Constraints Parsed';

    appState.files.push({
      name: file.name,
      size: sizeStr,
      parsed: parsedStr,
      url: fileUrl,
      content: `Extracted content from ${file.name}:\n- Parsed 14 Syllabus Topics\n- Identified 3 Assignment Deadlines\n- Target Minimum Attendance: 80%`
    });
  });

  renderFiles();
  showToast(`✨ ${files.length} PDF / File(s) added! Click any file below to open.`);
}

function renderFiles() {
  const container = document.getElementById('files-list');
  if (!container) return;

  container.innerHTML = '';
  appState.files.forEach((f, idx) => {
    const item = document.createElement('div');
    item.className = 'file-chip';
    item.onclick = () => openPdfViewer(idx);

    item.innerHTML = `
      <div style="display: flex; align-items: center; gap: 0.6rem;">
        <i data-lucide="${f.name.endsWith('.pdf') ? 'file-text' : 'file-code'}" style="color: #38BDF8; width: 18px;"></i>
        <div>
          <strong style="color: white;">${f.name}</strong>
          <div style="font-size: 0.72rem; color: #94A3B8;">${f.size} • <span style="color: #34D399;">${f.parsed}</span></div>
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 0.5rem;">
        <span style="font-size: 0.75rem; background: rgba(124,58,237,0.2); color: #C084FC; padding: 0.15rem 0.5rem; border-radius: 6px;">Open</span>
        <span style="cursor: pointer; color: #EF4444;" onclick="event.stopPropagation(); removeFile(${idx})">&times;</span>
      </div>
    `;
    container.appendChild(item);
  });
  if (window.lucide) lucide.createIcons();
}

function removeFile(idx) {
  playSound('click');
  appState.files.splice(idx, 1);
  renderFiles();
}

function toggleFreeSlot(el) {
  playSound('click');
  el.classList.toggle('selected');
}

/* ==========================================================================
   AI SCHEDULE GENERATION & TIMING EDITOR
   ========================================================================== */
function generateCustomAISchedule() {
  playSound('replan');

  if (appState.subjects.length === 0) {
    showToast('⚠️ Please add at least one subject first.');
    return;
  }

  const newBlocks = [];
  const timesets = [
    { start: '07:30', end: '08:45' },
    { start: '14:00', end: '15:30' },
    { start: '16:00', end: '17:30' },
    { start: '19:00', end: '20:30' }
  ];

  appState.subjects.forEach((subj, idx) => {
    const time = timesets[idx % timesets.length];
    newBlocks.push({
      id: 'block-' + Date.now() + '-' + idx,
      subject: subj.name,
      topic: `${subj.name} Core Revision & Problem Solving`,
      startTime: time.start,
      endTime: time.end,
      priority: subj.priority,
      done: false
    });
  });

  appState.scheduleBlocks = newBlocks;
  renderScheduleBlocks();
  showToast('🎉 AI Personalized Schedule updated matching free slots!');
}

function renderScheduleBlocks() {
  const container = document.getElementById('schedule-blocks-container');
  if (!container) return;

  container.innerHTML = '';
  appState.scheduleBlocks.forEach(b => {
    const item = document.createElement('div');
    item.className = `schedule-block-item ${b.done ? 'done' : ''}`;
    const prioColor = b.priority === 'Critical' ? '#EF4444' : b.priority === 'High' ? '#FBBF24' : '#34D399';

    item.innerHTML = `
      <div class="block-top-row">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
          <div class="task-check" onclick="toggleScheduleDone('${b.id}')">
            ${b.done ? '<i data-lucide="check" style="width: 14px; color: white;"></i>' : ''}
          </div>
          <div>
            <strong>${b.subject}</strong>
            <div style="font-size: 0.8rem; color: #CBD5E1;">${b.topic}</div>
          </div>
        </div>
        <span style="font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 6px; background: rgba(255,255,255,0.08); color: ${prioColor}; border: 1px solid ${prioColor}40;">
          ${b.priority}
        </span>
      </div>

      <div class="block-time-edit-row">
        <span style="color: var(--text-muted);">Timing:</span>
        <input type="time" class="time-input" value="${b.startTime}" onchange="updateBlockStartTime('${b.id}', this.value)">
        <span>to</span>
        <input type="time" class="time-input" value="${b.endTime}" onchange="updateBlockEndTime('${b.id}', this.value)">
        <span style="margin-left: auto; color: #38BDF8; font-size: 0.75rem;"><i data-lucide="edit-3" style="width: 12px; display: inline;"></i> Editable</span>
      </div>
    `;
    container.appendChild(item);
  });

  if (window.lucide) lucide.createIcons();
  updateMetrics();
}

function toggleScheduleDone(id) {
  playSound('click');
  const block = appState.scheduleBlocks.find(b => b.id === id);
  if (block) {
    block.done = !block.done;
    if (block.done) playSound('success');
    renderScheduleBlocks();
  }
}

function updateBlockStartTime(id, newStart) {
  playSound('click');
  const block = appState.scheduleBlocks.find(b => b.id === id);
  if (block) {
    block.startTime = newStart;
    showToast(`⏱️ Start time updated to ${newStart}`);
  }
}

function updateBlockEndTime(id, newEnd) {
  playSound('click');
  const block = appState.scheduleBlocks.find(b => b.id === id);
  if (block) {
    block.endTime = newEnd;
    showToast(`⏱️ End time updated to ${newEnd}`);
  }
}

function updateMetrics() {
  let totalAtt = 0;
  appState.subjects.forEach(s => totalAtt += s.attendance);
  const avgAtt = appState.subjects.length > 0 ? (totalAtt / appState.subjects.length).toFixed(1) : 87.5;

  const attendEl = document.getElementById('dash-attend-avg');
  if (attendEl) attendEl.textContent = avgAtt + '%';

  const pending = appState.scheduleBlocks.filter(b => !b.done).length;
  const pendingEl = document.getElementById('dash-pending-val');
  if (pendingEl) pendingEl.textContent = `${pending} Slots`;
}

function switchDashboardTab(btn, tabId) {
  playSound('click');
  document.querySelectorAll('.sidebar-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  const scheduleView = document.getElementById('tab-schedule-view');
  const timerView = document.getElementById('tab-timer-view');

  if (tabId === 'tab-timer') {
    if (scheduleView) scheduleView.style.display = 'none';
    if (timerView) timerView.style.display = 'block';
  } else {
    if (scheduleView) scheduleView.style.display = 'block';
    if (timerView) timerView.style.display = 'none';
  }
}

function exportScheduleCSV() {
  playSound('success');
  showToast('📥 Google Calendar ICS Sync exported successfully!');
}

function showToast(msg) {
  const toast = document.createElement('div');
  toast.style.cssText = `
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    background: rgba(13, 18, 38, 0.95);
    border: 1px solid var(--primary);
    box-shadow: 0 10px 30px rgba(124, 58, 237, 0.4);
    color: white;
    padding: 0.85rem 1.25rem;
    border-radius: 12px;
    z-index: 3000;
    font-size: 0.88rem;
    backdrop-filter: blur(16px);
  `;
  toast.innerHTML = msg;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.4s ease';
    setTimeout(() => toast.remove(), 400);
  }, 2800);
}

function triggerRescheduleSimulation() {
  playSound('replan');
  showToast('🔄 AI Engine recalculated slots to avoid attendance risks!');
}

function highlightWorkflowStep(el) {
  playSound('click');
  document.querySelectorAll('.workflow-step').forEach(s => s.classList.remove('active'));
  el.classList.add('active');
}

/* ==========================================================================
   AURORA CANVAS & PARTICLES
   ========================================================================== */
function initAuroraCanvas() {
  const canvas = document.getElementById('aurora-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let width = canvas.width = window.innerWidth;
  let height = canvas.height = window.innerHeight;

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  });

  const particles = [];
  const particleCount = Math.min(Math.floor(width / 22), 60);

  for (let i = 0; i < particleCount; i++) {
    particles.push({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      radius: Math.random() * 2 + 1,
      color: i % 3 === 0 ? 'rgba(124, 58, 237, ' : i % 3 === 1 ? 'rgba(37, 99, 235, ' : 'rgba(6, 182, 212, ',
      alpha: Math.random() * 0.5 + 0.2
    });
  }

  function animate() {
    ctx.clearRect(0, 0, width, height);

    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0 || p.x > width) p.vx *= -1;
      if (p.y < 0 || p.y > height) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = p.color + p.alpha + ')';
      ctx.fill();

      for (let j = i + 1; j < particles.length; j++) {
        const p2 = particles[j];
        const dx = p.x - p2.x;
        const dy = p.y - p2.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 110) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = `rgba(147, 51, 234, ${0.12 * (1 - dist / 110)})`;
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(animate);
  }

  animate();
}

function initMouseGlow() {
  const glow = document.getElementById('mouse-glow');
  if (!glow) return;
  window.addEventListener('mousemove', (e) => {
    glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%, -50%)`;
  });
}

function initCounters() {
  const counters = [
    { id: 'counter-1', target: 78, suffix: '%' },
    { id: 'counter-2', target: 4.5, suffix: 'h', decimals: 1 },
    { id: 'counter-3', target: 82, suffix: '%' },
    { id: 'counter-4', target: 3.8, suffix: 'x', decimals: 1 }
  ];

  let animated = false;
  window.addEventListener('scroll', () => {
    const el = document.getElementById('counter-1');
    if (!el || animated) return;

    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom >= 0) {
      animated = true;
      counters.forEach(c => {
        const targetEl = document.getElementById(c.id);
        if (!targetEl) return;

        let start = 0;
        const duration = 1400;
        const startTime = performance.now();

        function update(currentTime) {
          const elapsed = currentTime - startTime;
          const progress = Math.min(elapsed / duration, 1);
          const value = start + (c.target - start) * progress;

          targetEl.textContent = (c.decimals ? value.toFixed(c.decimals) : Math.floor(value)) + c.suffix;
          if (progress < 1) requestAnimationFrame(update);
        }
        requestAnimationFrame(update);
      });
    }
  });
}

/* ==========================================================================
   POMODORO FOCUS TIMER
   ========================================================================== */
let timerInterval = null;
let timerSeconds = 25 * 60;
let isTimerRunning = false;

function initFocusTimer() {
  updateTimerDisplay();
}

function updateTimerDisplay() {
  const display = document.getElementById('timer-display');
  if (!display) return;

  const mins = Math.floor(timerSeconds / 60);
  const secs = timerSeconds % 60;
  display.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

function startFocusTimer() {
  playSound('click');
  const btn = document.getElementById('timer-toggle-btn');
  if (!btn) return;

  if (!isTimerRunning) {
    isTimerRunning = true;
    btn.innerHTML = `<i data-lucide="pause"></i> Pause`;
    if (window.lucide) lucide.createIcons();

    timerInterval = setInterval(() => {
      if (timerSeconds > 0) {
        timerSeconds--;
        updateTimerDisplay();
      } else {
        clearInterval(timerInterval);
        isTimerRunning = false;
        btn.innerHTML = `<i data-lucide="play"></i> Start`;
        playSound('success');
        showToast('🎉 Focus session completed! Take a 5-minute break.');
      }
    }, 1000);
  } else {
    clearInterval(timerInterval);
    isTimerRunning = false;
    btn.innerHTML = `<i data-lucide="play"></i> Start`;
    if (window.lucide) lucide.createIcons();
  }
}

function resetFocusTimer() {
  playSound('click');
  clearInterval(timerInterval);
  isTimerRunning = false;
  timerSeconds = 25 * 60;
  updateTimerDisplay();

  const btn = document.getElementById('timer-toggle-btn');
  if (btn) {
    btn.innerHTML = `<i data-lucide="play"></i> Start`;
    if (window.lucide) lucide.createIcons();
  }
}

/* ==========================================================================
   IMPACT CALCULATOR
   ========================================================================== */
function updateCalculator() {
  const tasksInput = document.getElementById('slider-tasks');
  const hoursInput = document.getElementById('slider-hours');
  if (!tasksInput || !hoursInput) return;

  const tasks = parseInt(tasksInput.value);
  const hours = parseInt(hoursInput.value);

  document.getElementById('slider-tasks-val').textContent = `${tasks} Tasks`;
  document.getElementById('slider-hours-val').textContent = `${hours} Hours`;

  const timeSaved = (tasks * 0.6 + hours * 0.25).toFixed(1);
  const gpaBoost = Math.min(0.2 + (tasks * 0.04) + (hours * 0.015), 0.85).toFixed(2);

  document.getElementById('res-time-saved').textContent = `${timeSaved} Hours/wk`;
  document.getElementById('res-gpa-boost').textContent = `+${gpaBoost} GPA`;
}

/* ==========================================================================
   DEMO MODAL
   ========================================================================== */
function openDemoModal() {
  playSound('click');
  const modal = document.getElementById('demo-modal');
  if (modal) modal.classList.add('active');
}

function closeDemoModal() {
  playSound('click');
  const modal = document.getElementById('demo-modal');
  if (modal) modal.classList.remove('active');
}

function handleDemoSubmit(e) {
  e.preventDefault();
  playSound('replan');

  const subject = document.getElementById('input-subject').value;
  const urgency = document.getElementById('input-urgency').value;
  const resultDiv = document.getElementById('demo-result');
  const resultText = document.getElementById('demo-result-text');

  if (!resultDiv || !resultText) return;
  resultDiv.style.display = 'block';
  resultText.innerHTML = `
    Assigned <strong>${subject}</strong> high priority (${urgency.toUpperCase()}). 
    Created 3 dedicated study blocks totaling 4.5 hours with automatic rest intervals synced to Google Calendar.
  `;
}
